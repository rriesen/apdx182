#!/usr/bin/perl

use File::Basename;
@command = split /\s+/, basename($0);
@fn = split /\./, $command[0];

%n_comp_cpus_per_node = (
    '20+0', '10',
    '16+0', '8',
    '16+16', '8',
    '20+20', '10',
    '16+4', '8',
    );
%cpuset0 = (
    '20+0', '0-9',
    '16+0', '0-9',
    '16+16', '0-9',
    '20+20', '0-9',
    '16+4', '0-9',
);
%cpuset1 = (
    '20+0', '10-19',
    '16+0', '10-19',
    '16+16', '10-19',
    '20+20', '10-19',
    '16+4', '10-19',
);
%nodeset0 = (
    '20+0', '0',
    '16+0', '0',
    '16+16', '0',
    '20+20', '0',
    '16+4', '0',
);
%nodeset1 = (
    '20+0', '1',
    '16+0', '1',
    '16+16', '1',
    '20+20', '1',
    '16+4', '1',
);

%progress = (
    '20+0',  '-genv MV2_ENABLE_AFFINITY 0 -genv MV2_CPU_MAPPING 0:1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19',
    '16+0',  '-genv MV2_ENABLE_AFFINITY 0 -genv MV2_CPU_MAPPING 2:3:4:5:6:7:8:9:12:13:14:15:16:17:18:19',
    '16+16', '-genv MV2_ENABLE_AFFINITY 0 -genv MV2_CPU_MAPPING 2:3:4:5:6:7:8:9:12:13:14:15:16:17:18:19 -genv MPIR_CVAR_ASYNC_PROGRESS 1 -genv DISABLE_UTI 1',
    '20+20', '-genv MV2_ENABLE_AFFINITY 0 -genv MV2_CPU_MAPPING 0:1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19 -genv MPIR_CVAR_ASYNC_PROGRESS 1 -genv DISABLE_UTI 1',
    '16+4',  '-genv MV2_ENABLE_AFFINITY 0 -genv MV2_CPU_MAPPING 2:3:4:5:6:7:8:9:12:13:14:15:16:17:18:19 -genv MPIR_CVAR_ASYNC_PROGRESS 1 -genv MV2_ASYNC_PROGRESS_CPU_MAPPING 0:1:10:11 -genv MV2_NUM_NUMA_NODES 2 -genv MV2_NUM_CPUS_PER_NUMA_NODE 10 -genv UTI_CPU_SET 0-1,10-11',
    '20+20b', '-genv MV2_ENABLE_AFFINITY 0 -genv MV2_CPU_MAPPING 0:1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19 -genv MPIR_CVAR_ASYNC_PROGRESS 1 -genv MV2_ASYNC_PROGRESS_CPU_MAPPING 0:1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19 -genv MV2_NUM_NUMA_NODES 2 -genv MV2_NUM_CPUS_PER_NUMA_NODE 10'
);

sleep(1);
$dir=$ARGV[0].'_'.$ARGV[1].'_'.`date +%Y%m%d_%H%M%S`;
print $dir."\n";
chomp($dir);
mkdir $dir;
chdir $dir;
open(IN, "../job.sh.in");
open(OUT, ">./job.sh");
while(<IN>) {
    s/\@jobname/$fn[0]/g;
    s/\@nprocs/$ARGV[0]/g;
    s/\@nnodes/$ARGV[1]/g;
    s/\@progress/$progress{$ARGV[2]}/g;
    print OUT $_;
}
close(IN);
close(OUT);

open(IN, "../numactl.sh.in");
open(OUT, ">./numactl.sh");
while(<IN>) {
    s/\@exe/\.\.\/nwchem\-6\.6\/bin\/LINUX64\/nwchem \.\.\/jhammond\/w10_ccsd_cc\-pvdz_energy\.nw/g;
    s/\@n_comp_cpus_per_node/$n_comp_cpus_per_node{$ARGV[2]}/g;
    s/\@cpuset0/$cpuset0{$ARGV[2]}/g;
    s/\@cpuset1/$cpuset1{$ARGV[2]}/g;
    s/\@nodeset0/$nodeset0{$ARGV[2]}/g;
    s/\@nodeset1/$nodeset1{$ARGV[2]}/g;
    print OUT $_;
}
close(IN);
close(OUT);
chmod(0766, './numactl.sh');

system("qsub ./job.sh");
