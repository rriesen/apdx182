/*
 * Copyright © 2015 Inria.  All rights reserved.
 * See COPYING in top-level directory.
 */

#ifndef HWLOC_PORT_CUDA_CUDA_H
#define HWLOC_PORT_CUDA_CUDA_H

#define CUDA_VERSION 4000

#endif /* HWLOC_PORT_CUDA_CUDA_H */
